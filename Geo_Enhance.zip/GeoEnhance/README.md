# GeoEnhance — See Beyond Resolution

Flask-based satellite image super-resolution demo using a trained lightweight SwinIR 4x model.

## Run locally

Requires Python 3.10.

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
pip install -r requirements.txt
python app.py
```

Upload a 4-band, 130 x 130, uint16 GeoTIFF (RGB + NIR) through the UI.
The application generates a 4x output GeoTIFF and RGB previews.

**Preview disclosure:** The LR image shown in the interface may include display-only simulated blur and noise; the model processes the unmodified uploaded GeoTIFF. Such previews should not be used to judge the model's improvement.

Output pixel dimensions increase 4x per axis, but this does not guarantee new physical ground detail.
