document.addEventListener("DOMContentLoaded", () => {
    const dropZone = document.getElementById("dropZone");
    const fileInput = document.getElementById("fileInput");
    const browseBtn = document.getElementById("browseBtn");
    const enhanceBtn = document.getElementById("enhanceBtn");
    const selectedFile = document.getElementById("selectedFile");
    const fileName = document.getElementById("fileName");
    const processingState = document.getElementById("processingState");
    const errorMessage = document.getElementById("errorMessage");

    const resultsSection = document.getElementById("resultsSection");
    const lrImage = document.getElementById("lrImage");
    const srImage = document.getElementById("srImage");
    const downloadBtn = document.getElementById("downloadBtn");
    const resultFilename = document.getElementById("resultFilename");

    let currentFile = null;

    function showError(message) {
        errorMessage.textContent = message;
        errorMessage.hidden = false;
    }

    function clearError() {
        errorMessage.textContent = "";
        errorMessage.hidden = true;
    }

    function chooseFile(file) {
        clearError();

        if (!file) return;

        if (!/\.tiff?$/i.test(file.name)) {
            showError("Please select a GeoTIFF file (.tif or .tiff).");
            return;
        }

        if (file.size > 25 * 1024 * 1024) {
            showError("File exceeds the 25 MB upload limit.");
            return;
        }

        currentFile = file;
        fileName.textContent = file.name;
        selectedFile.hidden = false;
        enhanceBtn.disabled = false;
        resultsSection.hidden = true;
    }

    browseBtn.addEventListener("click", () => {
        fileInput.click();
    });

    fileInput.addEventListener("change", () => {
        chooseFile(fileInput.files[0]);
    });

    dropZone.addEventListener("dragover", (event) => {
        event.preventDefault();
        dropZone.classList.add("dragover");
    });

    dropZone.addEventListener("dragleave", () => {
        dropZone.classList.remove("dragover");
    });

    dropZone.addEventListener("drop", (event) => {
        event.preventDefault();
        dropZone.classList.remove("dragover");

        if (event.dataTransfer.files.length > 0) {
            chooseFile(event.dataTransfer.files[0]);
        }
    });

    enhanceBtn.addEventListener("click", async () => {
        if (!currentFile) {
            showError("Please select a satellite image first.");
            return;
        }

        clearError();
        resultsSection.hidden = true;
        processingState.hidden = false;
        enhanceBtn.disabled = true;

        const formData = new FormData();
        formData.append("file", currentFile);

        try {
            const response = await fetch("/api/enhance", {
                method: "POST",
                body: formData
            });

            const data = await response.json();

            if (!response.ok || data.error) {
                throw new Error(
                    data.error || "Image enhancement failed."
                );
            }

            /*
             * Expected backend response:
             * {
             *   "lr_preview": "/outputs/...",
             *   "sr_preview": "/outputs/...",
             *   "download_url": "/outputs/..."
             * }
             */

            const lrUrl = data.lr_preview;
            const srUrl = data.sr_preview;
            const downloadUrl = data.download_url;

            if (!lrUrl || !srUrl || !downloadUrl) {
                throw new Error(
                    "Backend response is missing preview or download URLs."
                );
            }

            const cacheBust = `?v=${Date.now()}`;

            lrImage.src = lrUrl + cacheBust;
            srImage.src = srUrl + cacheBust;
            downloadBtn.href = downloadUrl;

            resultFilename.textContent =
                currentFile.name + " — 4× SR generated";

            resultsSection.hidden = false;

            resultsSection.scrollIntoView({
                behavior: "smooth",
                block: "start"
            });

        } catch (error) {
            console.error("GeoEnhance error:", error);
            showError(error.message);
        } finally {
            processingState.hidden = true;
            enhanceBtn.disabled = false;
        }
    });
});